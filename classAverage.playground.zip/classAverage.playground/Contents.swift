import UIKit

//A variable that holds the name of each student in the class
var name = ["Ruby", "Kamari", "Donald", "DeVonte", "Anna" ,"Desmon","Isaiah","Ikenna","Devon","Adarsh",  "Raquel","Hayley","DeAntre","Tyler",  "Khyree","Jasmine","Mackenzie","Keneisha","Michael","Sagar", "Amarachi","Shantal","Stephone","Nkem","Dhruvkumar","Gaeshawn"]





print("Total number of students:", separator: "")

print(name.count)



//varible to hold sum for total number of characters

var sum = 0





//for to loop through array and add all the charcaters in all the names

for character in name{
    
    let charCount = character.count
    
    sum += charCount
    
}



//computing the average of the characters and the students names

var average = sum/name.count



//printing results

print("Total number of characters in students name:")

print(sum)



print("The average:")

print(average)





